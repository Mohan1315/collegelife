#include <stdio.h>
int main()
{
int a,b;
int c=a+b;
printf("%d",c); // Output: 5
return 0;
}
