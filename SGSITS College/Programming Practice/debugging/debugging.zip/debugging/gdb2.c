#include <stdio.h>
int main()
{
int d=2;
printf("Enter the value of d:");
scanf("%d",d);
printf("The value of d is:%d",d);
return 0;
}
