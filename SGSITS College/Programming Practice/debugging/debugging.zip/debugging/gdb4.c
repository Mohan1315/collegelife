#include <stdio.h>
int main(void)
{
int arr[2];
arr[3] = 10; // Accessing out of bound
return (0); 

}

