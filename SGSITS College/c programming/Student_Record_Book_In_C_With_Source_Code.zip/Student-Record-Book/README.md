# Student-Record-Book
This project is in C language on student record book. this project has feature to add student data such as their contact info and their name roll number and their opted subjects and marks obtained and finally based on these information system Generate Marksheet. 
