#include <stdio.h>
int main()
{
int *p;
printf("%d",*p);
return 0;
}
